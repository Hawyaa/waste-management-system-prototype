document.addEventListener('DOMContentLoaded', function() {
    // Create waste type distribution chart
    const wasteTypeData = {
        values: [],
        labels: [],
        type: 'pie'
    };

    const wasteTypeLayout = {
        title: 'Waste Type Distribution',
        height: 400,
        margin: { t: 30, b: 30, l: 30, r: 30 }
    };

    Plotly.newPlot('wasteTypeChart', [wasteTypeData], wasteTypeLayout);

    // Create time series chart
    const timeSeriesData = {
        x: [],
        y: [],
        type: 'scatter',
        mode: 'lines+markers'
    };

    const timeSeriesLayout = {
        title: 'Waste Collection Over Time',
        xaxis: { title: 'Date' },
        yaxis: { title: 'Quantity' },
        height: 400,
        margin: { t: 30, b: 50, l: 50, r: 30 }
    };

    Plotly.newPlot('timeSeriesChart', [timeSeriesData], timeSeriesLayout);
});
