from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
import os
from sqlalchemy import func
import json

basedir = os.path.abspath(os.path.dirname(__file__))

# Create the Flask application
app = Flask(__name__)

# Configure the application
app.config['SECRET_KEY'] = 'your-secret-key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'waste_management.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(minutes=60)

# Initialize SQLAlchemy
db = SQLAlchemy(app)

# Initialize Login Manager
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# User Model
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128))
    role = db.Column(db.String(20), nullable=False, default='user')
    waste_records = db.relationship('WasteRecord', backref='user', lazy=True)
    reports = db.relationship('Report', backref='user', lazy=True)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

# Waste Record Model
class WasteRecord(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    waste_type = db.Column(db.String(50), nullable=False)
    quantity = db.Column(db.Float, nullable=False)
    unit = db.Column(db.String(20), nullable=False)
    timestamp = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    location = db.Column(db.String(100), nullable=False)
    description = db.Column(db.String(200))
    status = db.Column(db.String(20), default='pending')
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

# Report Model
class Report(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    content = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
        
    if request.method == 'POST':
        try:
            username = request.form['username']
            email = request.form['email']
            password = request.form['password']
            
            if User.query.filter_by(username=username).first():
                flash('Username already exists', 'error')
                return redirect(url_for('register'))
            
            if User.query.filter_by(email=email).first():
                flash('Email already registered', 'error')
                return redirect(url_for('register'))
            
            user = User(username=username, email=email)
            user.set_password(password)
            db.session.add(user)
            db.session.commit()
            
            flash('Registration successful! Please login.', 'success')
            return redirect(url_for('login'))
        except Exception as e:
            flash(f'Error during registration: {str(e)}', 'error')
            return redirect(url_for('register'))
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
        
    if request.method == 'POST':
        try:
            username = request.form['username']
            password = request.form['password']
            user = User.query.filter_by(username=username).first()
            
            if user and user.check_password(password):
                login_user(user, remember=True)
                session.permanent = True
                flash('Logged in successfully!', 'success')
                next_page = request.args.get('next')
                return redirect(next_page or url_for('dashboard'))
            else:
                flash('Invalid username or password', 'error')
        except Exception as e:
            flash(f'Error during login: {str(e)}', 'error')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Logged out successfully.', 'success')
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    # Get waste records for the current user
    waste_records = WasteRecord.query.filter_by(user_id=current_user.id).order_by(WasteRecord.timestamp.desc()).all()
    
    # Calculate statistics
    total_waste = db.session.query(func.sum(WasteRecord.quantity)).filter_by(user_id=current_user.id).scalar() or 0
    waste_by_type = db.session.query(
        WasteRecord.waste_type,
        func.sum(WasteRecord.quantity).label('total')
    ).filter_by(user_id=current_user.id).group_by(WasteRecord.waste_type).all()
    
    stats = {
        'total_waste': total_waste,
        'waste_by_type': dict(waste_by_type)
    }
    
    return render_template('dashboard.html', waste_records=waste_records, stats=stats)

@app.route('/add_record', methods=['GET', 'POST'])
@login_required
def add_record():
    if request.method == 'POST':
        try:
            waste_record = WasteRecord(
                waste_type=request.form['waste_type'],
                quantity=float(request.form['quantity']),
                unit=request.form['unit'],
                location=request.form['location'],
                description=request.form.get('description', ''),
                user_id=current_user.id
            )
            db.session.add(waste_record)
            db.session.commit()
            flash('Record added successfully', 'success')
            return redirect(url_for('dashboard'))
        except Exception as e:
            flash(f'Error adding record: {str(e)}', 'error')
            return redirect(url_for('add_record'))
    return render_template('add_record.html')

@app.route('/edit_record/<int:record_id>', methods=['GET', 'POST'])
@login_required
def edit_record(record_id):
    record = WasteRecord.query.get_or_404(record_id)
    if record.user_id != current_user.id:
        flash('Unauthorized access', 'error')
        return redirect(url_for('dashboard'))
        
    if request.method == 'POST':
        try:
            record.waste_type = request.form['waste_type']
            record.quantity = float(request.form['quantity'])
            record.unit = request.form['unit']
            record.location = request.form['location']
            record.description = request.form.get('description', '')
            db.session.commit()
            flash('Record updated successfully', 'success')
            return redirect(url_for('dashboard'))
        except Exception as e:
            flash(f'Error updating record: {str(e)}', 'error')
    
    return render_template('edit_record.html', record=record)

@app.route('/delete_record/<int:record_id>')
@login_required
def delete_record(record_id):
    record = WasteRecord.query.get_or_404(record_id)
    if record.user_id != current_user.id:
        flash('Unauthorized access', 'error')
        return redirect(url_for('dashboard'))
        
    try:
        db.session.delete(record)
        db.session.commit()
        flash('Record deleted successfully', 'success')
    except Exception as e:
        flash(f'Error deleting record: {str(e)}', 'error')
    
    return redirect(url_for('dashboard'))

@app.route('/api/waste_stats')
@login_required
def waste_stats():
    # Get waste statistics for charts
    waste_by_type = db.session.query(
        WasteRecord.waste_type,
        func.sum(WasteRecord.quantity).label('total')
    ).filter_by(user_id=current_user.id).group_by(WasteRecord.waste_type).all()
    
    # Get time series data
    time_series = db.session.query(
        func.date(WasteRecord.timestamp),
        func.sum(WasteRecord.quantity)
    ).filter_by(user_id=current_user.id).group_by(
        func.date(WasteRecord.timestamp)
    ).order_by(func.date(WasteRecord.timestamp)).all()
    
    return jsonify({
        'waste_by_type': dict(waste_by_type),
        'time_series': {str(date): float(total) for date, total in time_series}
    })

@app.route('/reports')
@login_required
def reports():
    user_reports = Report.query.filter_by(user_id=current_user.id).order_by(Report.timestamp.desc()).all()
    return render_template('reports.html', reports=user_reports)

@app.route('/create_report', methods=['GET', 'POST'])
@login_required
def create_report():
    if request.method == 'POST':
        try:
            title = request.form['title']
            content = request.form['content']
            
            report = Report(
                title=title,
                content=content,
                user_id=current_user.id
            )
            db.session.add(report)
            db.session.commit()
            
            flash('Report created successfully', 'success')
            return redirect(url_for('reports'))
        except Exception as e:
            flash(f'Error creating report: {str(e)}', 'error')
    
    return render_template('create_report.html')

@app.route('/view_report/<int:report_id>')
@login_required
def view_report(report_id):
    report = Report.query.get_or_404(report_id)
    if report.user_id != current_user.id:
        flash('Unauthorized access', 'error')
        return redirect(url_for('reports'))
    return render_template('view_report.html', report=report)

@app.route('/delete_report/<int:report_id>')
@login_required
def delete_report(report_id):
    report = Report.query.get_or_404(report_id)
    if report.user_id != current_user.id:
        flash('Unauthorized access', 'error')
        return redirect(url_for('reports'))
    
    try:
        db.session.delete(report)
        db.session.commit()
        flash('Report deleted successfully', 'success')
    except Exception as e:
        flash(f'Error deleting report: {str(e)}', 'error')
    
    return redirect(url_for('reports'))

def create_admin():
    try:
        admin = User.query.filter_by(username='admin').first()
        if not admin:
            admin = User(
                username='admin',
                email='admin@example.com',
                role='admin'
            )
            admin.set_password('admin123')
            db.session.add(admin)
            db.session.commit()
            print("Admin user created successfully")
    except Exception as e:
        print(f"Error creating admin user: {e}")
        db.session.rollback()

# Create all database tables
with app.app_context():
    try:
        db.create_all()
        create_admin()
        print("Database initialized successfully")
    except Exception as e:
        print(f"Error initializing database: {e}")

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000, debug=True)
